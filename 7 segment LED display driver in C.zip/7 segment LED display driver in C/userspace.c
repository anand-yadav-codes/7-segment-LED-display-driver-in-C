#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<time.h>

#define NUM_THREADS	2
#define BUFFER_LENGTH 256               ///< The buffer length (crude but fine)
static char receive[BUFFER_LENGTH];     ///< The receive buffer from the LKM

int main(){
	
   
   int ret, fd, input,hour,min, cont;
   char stringToSend[BUFFER_LENGTH];
   char stringToSend1[BUFFER_LENGTH];
   char a, b, c, d, e;
   printf("Starting device driver...\n");
   fd = open("/dev/leddriver", O_RDWR);             // Open the device with read/write access
   if (fd < 0)
      perror("Failed to open the device...");

   time_t theTime = time(NULL);
   struct tm *aTime = localtime(&theTime);

   cont=1;
   while(cont!=0)
   {
   	theTime = time(NULL);

   	struct tm *aTime = localtime(&theTime);
	printf("for current time : press 1\n for manual input : press 2\n to exit : Press 3\n ");		// Menu for our functions
   	scanf("%d", &input);

	switch(input){								
		case 1:												// Printing current time 24 hrs standard 
		hour = aTime->tm_hour;

   		min=aTime->tm_min;
     
    		stringToSend1[0]=hour/10 + '0';
    		stringToSend1[1]=hour%10+'0';    
		stringToSend1[2]=min/10+'0';
    		stringToSend1[3]=min%10+'0';	
		write(fd, stringToSend1, strlen(stringToSend1));
		break;
		
		case 2:																	
		printf("type in an input string of 4 digits/ charaters to display:\n"); 			//prompting the user to enter a string 
   		//scanf("%[^\n]%*c", stringToSend);
		//scanf("%[^\t\n]s",&stringToSend);
		//scanf("%s",str);
		
		scanf("%c%c%c%c%c",&a, &b, &c, &d , &e);
		stringToSend[0]=b;
		
		stringToSend[1]=c;
		stringToSend[2]=d;
		stringToSend[3]=e;

		printf("%c%c%c%c",b,c,d,e);
		write(fd, stringToSend, strlen(stringToSend));  					// write the four character/digit to driver
   		break;
	
	case 3:
		cont=0;											// To exit the program
		break;	
    }    
	
}
printf("End of Program");
	return 0;
}
