/**
 * A kernel module for controlling a GPIO LED/button pair. 
 * The device mounts devices via sysfs /sys/class/gpio/gpio115 and gpio49. 
 * Therefore, this test LKM circuit assumes that an LED is attached to
 * GPIO 49 which is on P9_23 and the button is attached to GPIO 115 on 
 * P9_27. 
*/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/gpio.h>       // Required for the GPIO functions
#include <linux/interrupt.h>  // Required for the IRQ code
#include <linux/device.h>         // Header to support the kernel Driver Model
#include <linux/fs.h>             // Header for the Linux file system support
#include <asm/uaccess.h>          // Required for the copy to user function
#include <linux/mutex.h>
#define  DEVICE_NAME "leddriver"    //< The device will appear at /dev/leddriver using this value
#define  CLASS_NAME  "char"        ///< The device class -- this is a character device driver

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Anand Yadav, Sahil Bhasin");
MODULE_DESCRIPTION("A driver for 4 digit 7 segment display");
MODULE_VERSION("1.0");

//static unsigned int microseconds=20;
static unsigned int dgt1 = 49;       //< hard coding the gpio for the digit
static unsigned int dgt2 = 26;       //< hard coding the gpio for the digit
static unsigned int dgt3 = 46;       //< hard coding the gpio for the digit

static unsigned int dgt4 = 65;       //< hard coding the gpio for the digit

static unsigned int segD = 66;       //< hard coding the LED gpio for this example to GPIO66
static unsigned int segA = 117;       //< hard coding the LED gpio for this example to GPIO69
static unsigned int segB = 44;	 //< hard coding the LED gpio for this example to GPIO45

static unsigned int segC = 67;       //< hard coding the LED gpio for this example to GPIO49
static unsigned int segG = 68;       //< hard coding the LED gpio for this example to GPIO66
static unsigned int segF = 112;       //< hard coding the LED gpio for this example to GPIO69
static unsigned int segE = 60;	 //< hard coding the LED gpio for this example to GPIO45


static unsigned int gpioButton = 115;   ///< hard coding the button gpio for this example to P9_27 (GPIO115)
static unsigned int irqNumber;          ///< Used to share the IRQ number within this file
static bool	    ledOn = 0;          ///< Is the LED on or off? Used to invert its state (off by default)

static DEFINE_MUTEX(driver_mutex);
static int    majorNumber;                  ///< Stores the device number -- determined automatically
static char   message[256] = {0};           ///< Memory for the string that is passed from userspace
static short  size_of_message;              ///< Used to remember the size of the string stored
static int    numberOpens = 0;              ///< Counts the number of times the device is opened
static struct class*  driverClass  = NULL; ///< The device-driver class struct pointer
static struct device* driverDevice = NULL; ///< The device-driver device struct pointer

/// Function prototype for the custom IRQ handler function -- see below for the implementation
static irq_handler_t  ebbgpio_irq_handler(unsigned int irq, void *dev_id, struct pt_regs *regs);
//static long millis();
/** @brief The LKM initialization function
 *  The static keyword restricts the visibility of the function to within this C file. The __init
 *  macro means that for a built-in driver (not a LKM) the function is only used at initialization
 *  time and that it can be discarded and its memory freed up after that point. In this example this
 *  function sets up the GPIOs and the IRQ
 *  @return returns 0 if successful
 */

// The prototype functions for the character driver -- must come before the struct definition
static int     dev_open(struct inode *, struct file *);
static int     dev_release(struct inode *, struct file *);
static ssize_t dev_write(struct file *, const char *, size_t, loff_t *);

/** @brief Devices are represented as file structure in the kernel. The file_operations structure from
 *  /linux/fs.h lists the callback functions that you wish to associated with your file operations
 *  using a C99 syntax structure. char devices usually implement open, read, write and release calls
 */
/*
static long millis(){
    struct timeval te; 
    gettimeofday(&te,0); // get current time
    long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
    //printf("milliseconds: %lld\n", milliseconds);
    return milliseconds;
}
*/

static struct file_operations fops =
{
   .open = dev_open,
   .write = dev_write,
   .release = dev_release,
};

 static int __init ebbgpio_init(void){
   int result;
	mutex_init(&driver_mutex); //intiating the lock
   
   
   printk(KERN_INFO "KDriver: Initializing the KDriver LKM\n");

   // Try to dynamically allocate a major number for the device -- more difficult but worth it
   majorNumber = register_chrdev(0, DEVICE_NAME, &fops);
   if (majorNumber<0){
      printk(KERN_ALERT "KDriver failed to register a major number\n");
      return majorNumber;
   }
   printk(KERN_INFO "KDriver: registered correctly with major number %d\n", majorNumber);

   // Register the device class
   driverClass = class_create(THIS_MODULE, CLASS_NAME);
   if (IS_ERR(driverClass)){                // Check for error and clean up if there is
      unregister_chrdev(majorNumber, DEVICE_NAME);
      printk(KERN_ALERT "Failed to register device class\n");
      return PTR_ERR(driverClass);          // Correct way to return an error on a pointer
   }
   printk(KERN_INFO "KDriver: device class registered correctly\n");

   // Register the device driver
   driverDevice = device_create(driverClass, NULL, MKDEV(majorNumber, 0), NULL, DEVICE_NAME);
   if (IS_ERR(driverDevice)){               // Clean up if there is an error
      class_destroy(driverClass);          
      unregister_chrdev(majorNumber, DEVICE_NAME);
      printk(KERN_ALERT "Failed to create the device\n");
      return PTR_ERR(driverDevice);
   }
   printk(KERN_INFO "KDriver: device class created correctly\n"); // Made it! device was initialized
   printk(KERN_INFO "GPIO_TEST: Initializing the GPIO_TEST LKM\n");
   // Is the GPIO a valid GPIO number (e.g., the BBB has 4x32 but not all available)
   if (!gpio_is_valid(dgt1)){
      printk(KERN_INFO "GPIO_TEST: invalid LED GPIO\n");
      return -ENODEV;
   }
   // Going to set up the LED. It is a GPIO in output mode and will be on by default
   ledOn = true;
   gpio_request(dgt1, "sysfs");          // gpioLED is hardcoded to 49, request it
   gpio_direction_output(dgt1, ledOn);   // Set the gpio to be in output mode and on
   gpio_export(dgt1, false);             // Causes gpio49 to appear in /sys/class/gpio

   gpio_request(dgt2, "sysfs");          
   gpio_direction_output(dgt2, ledOn);   
   gpio_export(dgt2, false);

   gpio_request(dgt3, "sysfs");          
   gpio_direction_output(dgt3, ledOn);   
   gpio_export(dgt3, false);

   gpio_request(dgt4, "sysfs");          
   gpio_direction_output(dgt4, ledOn);   
   gpio_export(dgt4, false);   

   gpio_request(segD, "sysfs");          
   gpio_direction_output(segD, ledOn);   
   gpio_export(segD, false);             

   gpio_request(segA, "sysfs");          
   gpio_direction_output(segA, ledOn);   
   gpio_export(segA, false);             
   gpio_request(segB, "sysfs");          
   gpio_direction_output(segB, ledOn);   
   gpio_export(segB, false);             

   gpio_request(segC, "sysfs");          
   gpio_direction_output(segC, ledOn);   
   gpio_export(segC, false);             

   gpio_request(segG, "sysfs");          
   gpio_direction_output(segG, ledOn);   
   gpio_export(segG, false);             

   gpio_request(segF, "sysfs");          
   gpio_direction_output(segF, ledOn);   
   gpio_export(segF, false);             

   gpio_request(segE, "sysfs");          
   gpio_direction_output(segE, ledOn);   
   gpio_export(segE, false);             


   gpio_request(gpioButton, "sysfs");       // Set up the gpioButton
   gpio_direction_input(gpioButton);        // Set the button GPIO to be an input
   gpio_set_debounce(gpioButton, 200);      // Debounce the button with a delay of 200ms
   gpio_export(gpioButton, false);          // Causes gpio115 to appear in /sys/class/gpio
			                    // the bool argument prevents the direction from being changed
   // Perform a quick test to see that the button is working as expected on LKM load
   printk(KERN_INFO "GPIO_TEST: The button state is currently: %d\n", gpio_get_value(gpioButton));

   // GPIO numbers and IRQ numbers are not the same! This function performs the mapping for us
   irqNumber = gpio_to_irq(gpioButton);
   printk(KERN_INFO "GPIO_TEST: The button is mapped to IRQ: %d\n", irqNumber);

   // This next call requests an interrupt line
   result = request_irq(irqNumber,             // The interrupt number requested
                        (irq_handler_t) ebbgpio_irq_handler, // The pointer to the handler function below
                        IRQF_TRIGGER_RISING,   // Interrupt on rising edge (button press, not release)
                        "ebb_gpio_handler",    // Used in /proc/interrupts to identify the owner
                        NULL);                 // The *dev_id for shared interrupt lines, NULL is okay

   printk(KERN_INFO "GPIO_TEST: The interrupt request result is: %d\n", result);
   return result;
}

/** @brief The LKM cleanup function
 *  Similar to the initialization function, it is static. The __exit macro notifies that if this
 *  code is used for a built-in driver (not a LKM) that this function is not required. Used to release the
 *  GPIOs and display cleanup messages.
 */
static void __exit ebbgpio_exit(void){
   printk(KERN_INFO "GPIO_TEST: The button state is currently: %d\n", gpio_get_value(gpioButton));
   gpio_set_value(dgt1, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(dgt1);                  // Unexport the LED GPIO
   gpio_free(dgt1);			     // free the LED GPIO
   
   gpio_set_value(dgt2, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(dgt2);                  // Unexport the LED GPIO
   gpio_free(dgt2);

   gpio_set_value(dgt3, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(dgt3);                  // Unexport the LED GPIO
   gpio_free(dgt3);

   gpio_set_value(dgt4, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(dgt4);                  // Unexport the LED GPIO
   gpio_free(dgt4);

   gpio_set_value(segD, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(segD);                  // Unexport the LED GPIO
   gpio_free(segD);			     // free the LED GPIO
   
   gpio_set_value(segA, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(segA);                  // Unexport the LED GPIO
   gpio_free(segA);			     // free the LED GPIO
   
   gpio_set_value(segB, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(segB);                  // Unexport the LED GPIO
   gpio_free(segB);			     // free the LED GPIO
   
   gpio_set_value(segC, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(segC);                  // Unexport the LED GPIO
   gpio_free(segC);			     // free the LED GPIO
   
   gpio_set_value(segG, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(segG);                  // Unexport the LED GPIO
   gpio_free(segG);			     // free the LED GPIO
   

   gpio_set_value(segF, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(segF);                  // Unexport the LED GPIO
   gpio_free(segF);			     // free the LED GPIO
   

   gpio_set_value(segE, 0);              // Turn the LED off, makes it clear the device was unloaded
   gpio_unexport(segE);                  // Unexport the LED GPIO
   gpio_free(segE);			     // free the LED GPIO
   
   free_irq(irqNumber, NULL);               // Free the IRQ number, no *dev_id required in this case
   gpio_unexport(gpioButton);               // Unexport the Button GPIO
   
   gpio_free(gpioButton);                   // Free the Button GPIO
   printk(KERN_INFO "GPIO_TEST: Goodbye from the LKM!\n");
   device_destroy(driverClass, MKDEV(majorNumber, 0));     // remove the device
   class_unregister(driverClass);                          // unregister the device class
   class_destroy(driverClass);                             // remove the device class
   unregister_chrdev(majorNumber, DEVICE_NAME);            // unregister the major number
   mutex_destroy(&driver_mutex);    			   // destroy the driver mutex
   printk(KERN_INFO "KDriver: Goodbye from the LKM!\n");
   
   }

/** @brief The GPIO IRQ Handler function
 *  This function is a custom interrupt handler that is attached to the GPIO above. The same interrupt
 *  handler cannot be invoked concurrently as the interrupt line is masked out until the function is complete.
 *  This function is static as it should not be invoked directly from outside of this file.
 *  @param irq    the IRQ number that is associated with the GPIO -- useful for logging.
 *  @param dev_id the *dev_id that is provided -- can be used to identify which device caused the interrupt
 *  Not used in this example as NULL is passed.
 *  @param regs   h/w specific register values -- only really ever used for debugging.
 *  return returns IRQ_HANDLED if successful -- should return IRQ_NONE otherwise.
 
 */
static int dev_open(struct inode *inodep, struct file *filep){
   mutex_lock(&driver_mutex); //locking  driver mutex 
   numberOpens++;
   printk(KERN_INFO "KDriver: Device has been opened %d time(s)\n", numberOpens);
   return 0;
}

static void dispNumber(char number){			// Handle each segment to match input char
   int On= 0;
   int Off = 1;
	
   switch(number){
	case '0':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, Off);
	break;

	case '1':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, Off);
	break;
	
	case '2':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, On);
	break;

	case '3':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, On);
	break;

	case '4':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case '5':
	gpio_set_value(segA, On);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case '6':
	gpio_set_value(segA, On);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case '7':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, Off);
	break;

	case '8':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case '9':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'a':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'b':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'c':
	gpio_set_value(segA, On);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, Off);
	break;

	case 'd':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, On);
	break;

	case 'e':
	gpio_set_value(segA, On);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'f':
	gpio_set_value(segA, On);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'l':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, Off);
	break;

	case 'h':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'i':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, Off);
	break;

	case 'j':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, Off);
	break;

	case 'n':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, On);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, On);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, On);
	break;

	case 'o':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, On);
	break;

	case 'p':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, On);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'r':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, On);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, On);
	break;

	case 's':
	gpio_set_value(segA, On);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'u':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, Off);
	break;

	case 'y':
	gpio_set_value(segA, Off);
	gpio_set_value(segB, On);
	gpio_set_value(segC, On);
	gpio_set_value(segD, On);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, On);
	gpio_set_value(segG, On);
	break;

	case 'z':
	gpio_set_value(segA, On);
	gpio_set_value(segB, On);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, On);
	gpio_set_value(segE, On);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, On);
	break;

	default :
	gpio_set_value(segA, Off);
	gpio_set_value(segB, Off);
	gpio_set_value(segC, Off);
	gpio_set_value(segD, Off);
	gpio_set_value(segE, Off);
	gpio_set_value(segF, Off);
	gpio_set_value(segG, Off);
	break;   

	}

}

static ssize_t dev_write(struct file *filep, const char *buffer, size_t len, loff_t *offset){
   //intially setting all the lights off when we recieve a write command and then based on the message recieved, we turn only requested lights on.
   //long beginTime = millis();
   int i,c;
   sprintf(message, "%s(%zu letters)", buffer, len);   // appending received string with its length
   size_of_message = strlen(message);                 // store the length of the stored message
   printk(KERN_INFO "KDriver: Received %zu characters from the user\n", len);

   
	

   gpio_set_value(dgt1, 0);			// Switching evrything off
   gpio_set_value(dgt2, 0);
   gpio_set_value(dgt3, 0);
   gpio_set_value(dgt4, 0);

   gpio_set_value(segD, 1);
   gpio_set_value(segA, 1);
   gpio_set_value(segB, 1);

   gpio_set_value(segC, 1);
   gpio_set_value(segG, 1);
   gpio_set_value(segF, 1);
   gpio_set_value(segE, 1);
	
   
	
	
	for(c=0;c<40000;c++){				// cases to print each digit seperately			
	for(i=0; i<=3; i++)
	{
		int a;
                switch(i){
		
		case 0:
		gpio_set_value(dgt1, 1);
		gpio_set_value(dgt2, 0);
		gpio_set_value(dgt3, 0);
		gpio_set_value(dgt4, 0);
		dispNumber(message[i]);
		for (a=0; a<10000;a++){}
		break;

		case 1:
		gpio_set_value(dgt1, 0);
		gpio_set_value(dgt2, 1);
                gpio_set_value(dgt3, 0);
                gpio_set_value(dgt4, 0);
		dispNumber(message[i]);
		for (a=0; a<10000;a++){}
		break;

		case 2:
		gpio_set_value(dgt1, 0);
                gpio_set_value(dgt2, 0);
                gpio_set_value(dgt3, 1);
		gpio_set_value(dgt4, 0);
		dispNumber(message[i]);
		for (a=0; a<10000;a++){}
		break;

		case 3:
		gpio_set_value(dgt1, 0);
                gpio_set_value(dgt2, 0);
                gpio_set_value(dgt3, 0);
		gpio_set_value(dgt4, 1);
		dispNumber(message[i]);
		for (a=0; a<10000;a++){}
		break;
		}
		
		gpio_set_value(segD, 1);
   		gpio_set_value(segA, 1);
		gpio_set_value(segB, 1);
		gpio_set_value(segC, 1);
		gpio_set_value(segG, 1);
		gpio_set_value(segF, 1);
		gpio_set_value(segE, 1);
		gpio_set_value(dgt1, 0);
                gpio_set_value(dgt2, 0);
                gpio_set_value(dgt3, 0);
		gpio_set_value(dgt4, 0);


	}
	
}   
   // checking the message and turning lights on or off accordingly.
}

/** @brief The device release function that is called whenever the device is closed/released by
 *  the userspace program
 *  @param inodep A pointer to an inode object (defined in linux/fs.h)
 *  @param filep A pointer to a file object (defined in linux/fs.h)
 */


static int dev_release(struct inode *inodep, struct file *filep){
   
   mutex_unlock(&driver_mutex); //unlock the mutex driver
   printk(KERN_INFO "KDriver: Device successfully closed\n");
  
   return 0;
}

 static irq_handler_t ebbgpio_irq_handler(unsigned int irq, void *dev_id, struct pt_regs *regs){
   // when we press the button, it will work as a reset. All the LEDs will be turned off.
   ledOn = 0;
   gpio_set_value(dgt1, ledOn);
   gpio_set_value(segD, ledOn);
   gpio_set_value(segA, ledOn);
   gpio_set_value(segB, ledOn);
   printk(KERN_INFO "GPIO_TEST: Interrupt! (button state is %d)\n", gpio_get_value(gpioButton));
   return (irq_handler_t) IRQ_HANDLED;      // Announce that the IRQ has been handled correctly
}

/// This next calls are  mandatory -- they identify the initialization function
/// and the cleanup function (as above).
module_init(ebbgpio_init);
module_exit(ebbgpio_exit);
